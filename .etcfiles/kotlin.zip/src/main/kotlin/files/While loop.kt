fun main(){
    var x = 10
    while(x>=0){
        println(x)
        x--
    }

    //do-while문
    var y = 2
    do{
        println("hello")
        y-=1
    }while(y>0)
}