return {
  summary = 'Reset node transforms.',
  description = 'Resets node transforms to the original ones defined in the model file.',
  arguments = {},
  returns = {},
  variants = {
    {
      arguments = {},
      returns = {}
    }
  }
}
