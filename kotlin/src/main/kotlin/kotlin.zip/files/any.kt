fun main(){
    var x: Any
    x = "Kotlin"

    if (x is String) {
        print(x.length)
    }

}