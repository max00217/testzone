fun main(){

    /*
    var i = 3
    if(i in 1..4){
        print(i)
    }
    for (i in 4 downTo 1) print(i)
    */


    /*
    for (i in 1..8 step 2) print(1)
    println()
    for ( i in 8 downTo 1 step 2) print(i)
    */

    

}

