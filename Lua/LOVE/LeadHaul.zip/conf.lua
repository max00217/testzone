function love.conf(t)
	t.window.depth = 16

	t.identity = "Lead haul"
	t.title = "Lead haul"
	t.console = false
	t.window.msaa = 0
	t.window.icon = "assets/icon.png"
	t.window.vsync = false
	t.window.height = 720
	t.window.width = 1280
end
