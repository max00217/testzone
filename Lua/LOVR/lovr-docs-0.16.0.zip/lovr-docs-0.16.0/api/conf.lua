function lovr.conf(t)
  t.modules.audio = false
  t.modules.graphics = false
  t.modules.headset = false
  t.window = nil
end
