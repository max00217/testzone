R - Rotate blocks left
T - Rotate blocks right