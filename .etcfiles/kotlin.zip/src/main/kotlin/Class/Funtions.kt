package Class

class Person0{
    var firstName: String = "a"
    var lastName: String = "b"
    var age: Int =  9831234

    fun getName() = println("My name is $firstName $lastName")
}

fun main(){
    val Saram = Person0()
    Saram.getName()

}