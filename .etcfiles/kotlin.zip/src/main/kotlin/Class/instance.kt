package Class

class Myclass{
    companion object{
        val name = "testClass"
        fun method(){
            println("Method")
        }
    }
}