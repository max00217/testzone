fun main(){
    var mylist = listOf(1,2,3,4,5)

    println("for example")
    for(item in mylist)
        print(item)

    println("\nforEach Example")
    mylist.forEach{print(it)}

}