package Fn
//fun 함수 이름(변수명:변수 자료형):반환값의 자료형{
//return 반환값
//}

fun foo(){
    println("This is cool.")
}

fun main(){
    foo()
    println("End Foo()")
}