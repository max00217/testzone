fun main(){
    var b: String? = "abc" //can ve set to null
    b = null //ok
    print(b)
}