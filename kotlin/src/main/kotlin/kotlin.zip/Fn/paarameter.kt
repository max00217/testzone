package Fn

fun double(x: Int): Int{
    return 2 * x
}

fun main() {
    val result = double(2)
    print(result)
}