return {
  summary = 'Clear the event queue.',
  description = 'Clears the event queue, removing any unprocessed events.',
  arguments = {},
  returns = {},
  variants = {
    {
      arguments = {},
      returns = {}
    }
  }
}
