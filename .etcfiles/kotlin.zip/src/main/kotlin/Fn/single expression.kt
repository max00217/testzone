//package Fn

//fun double(x: Int): = x * 2

//fun main(){
    //println("Double(5) is ${double(5)}")
//}