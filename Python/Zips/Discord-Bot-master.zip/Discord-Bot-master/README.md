<img src="https://www.adweek.com/wp-content/uploads/2021/01/DiscordLogo3-2.jpg" height="100">

# Discord Bot that plays music! ![python](https://img.shields.io/badge/Python-3.9.5%20-brightgreen)

I decided to create a simple Discord bot using Python and the Discord.py API.

**DO NOT COPY AND PASTE THIS CODE IF YOU DO NOT KNOW WHAT YOU ARE DOING.**

<img src= "https://github.com/eric-yeung/Discord-Bot/blob/master/unknown.png?raw=true" height="300">

## This bot as of right now can:

- Join the channel you're in
- Play from Youtube
- Pause
- Stop
- Resume
- Clear messages in channel

## To do:

- Add messages when commands are executed succesfully ✔
- Queue system
- Have the bot always on (I would have to pay for this option so it's really not worth it as of right now)
- Include eventual jokes
- use cogs to organize commands

## Dependecies:
**INSTALL THESE DEPENDECIES IN ORDER FOR THE CODE TO WORK**
- discord.py
- ffmpeg
- YouTube-dl
- dotenv
