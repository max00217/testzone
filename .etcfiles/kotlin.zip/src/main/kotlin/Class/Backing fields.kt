package Class

var counter = 0
    set(value){
        if (value >= 0)
            field = value
    }