fun main(){
    for(i in 1..9){
        println("2*$i = ${2*i}")
    }

    var a = "a"
    for(i in 1..5) {
        println("a*$i")
    }
}