fun main(){
    val arr = arrayOf(1, 2, 3)
    println(arr.contentToString())
    println(arr[0])
    println(arr.get(0))
    

}